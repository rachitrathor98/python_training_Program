#include<iostream>
using namespace std;
int main(){
    cout<<"Hello";
    return 0;
}